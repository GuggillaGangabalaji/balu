# Add this for facebook, instagram, youtube and other icons 
fontawesome link add to html to activate all the symbols such as instagram, facebook...

https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css


for index.html, style.css and main.js follow up with the video.
