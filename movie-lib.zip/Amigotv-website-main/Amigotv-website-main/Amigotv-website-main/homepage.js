import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import {
  getAuth,
  onAuthStateChanged,
  signOut,
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";
import {
  getFirestore,
  getDoc,
  doc,
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyBlvyNl5qyRXoBRA2c3ucTrMCx65LSmtMQ",
  authDomain: "logauth-c1c5c.firebaseapp.com",
  projectId: "logauth-c1c5c",
  storageBucket: "logauth-c1c5c.appspot.com",
  messagingSenderId: "654977810455",
  appId: "1:654977810455:web:734829817bc75f11a51c52",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

const auth = getAuth();
const db = getFirestore();

onAuthStateChanged(auth, (user) => {
  const loggedInUserId = localStorage.getItem("loggedInUserId");
  if (loggedInUserId) {
  }
});

const logoutButton = document.getElementById("logout");

logoutButton.addEventListener("click", () => {
  localStorage.removeItem("loggedInUserId");
  signOut(auth)
    .then(() => {
      window.location.href = "LogIndex.html";
    })
    .catch((error) => {
      console.error("Error Signing out:", error);
    });
});
